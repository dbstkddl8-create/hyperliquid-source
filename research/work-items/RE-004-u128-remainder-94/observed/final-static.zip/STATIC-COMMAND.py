from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path('/tmp/hl-resume-20261101/arithmetic')
OUT=ROOT/'work/final-static'
PREFIX=Path('/tmp/hl-resume-20261101/toolchain/prefix')
PROVIDER=PREFIX.parent/'PROVIDER-AUDIT.json'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def physical(path):
    path=Path(path)
    if path.is_symlink():
        raw=os.readlink(path).encode();return {'kind':'symlink-text','bytes':len(raw),'sha256':sha(raw)}
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1<<20),b''):digest.update(part)
    return {'kind':'file','bytes':path.stat().st_size,'sha256':digest.hexdigest()}
def git(repo,*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=repo,stdin=subprocess.DEVNULL)
def audit():
    files={};pins={}
    def walk(repo,prefix=''):
        for raw in git(repo,'ls-files','--stage','-z').split(b'\0'):
            if not raw:continue
            header,name=raw.split(b'\t',1);mode,oid,stage=header.decode().split();assert stage=='0';name=name.decode();rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
            path=repo/rel;key=prefix+name
            if mode=='160000':
                head=git(path,'rev-parse','HEAD').decode().strip();state=git(path,'status','--porcelain=v1','--untracked-files=all').decode();assert head==oid and not state; pins[key]={'index':oid,'actual':head,'clean':True};walk(path,key+'/')
            else:files[key]={'mode':mode,**physical(path)}
    walk(ROOT);assert len(pins)==7
    provider=json.loads(PROVIDER.read_text());assert physical(PROVIDER)['sha256']=='56969b4e39acf17cf6f60f7c94d840a06bb37feb89cc577d0dcadfed7a71fdd6'
    payloads={}
    for row in provider['payloads']:
        value=physical(PREFIX/row['path']);assert value['bytes']==row['bytes'] and value['sha256']==row['sha256'];payloads[row['path']]=value
    assert len(payloads)==103
    tools={name:physical(Path(shutil.which(name)).resolve()) for name in ['cc','ld.bfd','objdump']}
    return {'head':git(ROOT,'rev-parse','HEAD').decode().strip(),'tree':git(ROOT,'rev-parse','HEAD^{tree}').decode().strip(),'status':git(ROOT,'status','--porcelain=v1','--untracked-files=all').decode(),'physical_count':len(files),'physical':files,'pins':pins,'provider':payloads,'tools':tools}
assert not OUT.exists();OUT.mkdir()
script=Path(__file__).read_bytes();before=audit();assert not before['status']
(OUT/'BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
calls=[]
commands=[['make','-j1','PYTHON=python3 -B',name] for name in ['doctor','verify','catalogue-check','reproduce']]
commands.append(['python3','-B','-m','unittest','tests.test_u128_remainder_contract','-v'])
for index,argv in enumerate(commands):
    start=time.monotonic();result=subprocess.run(argv,cwd=ROOT,stdin=subprocess.DEVNULL,capture_output=True,timeout=180)
    logs={}
    for kind,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
        name=f'{index}-{argv[-1]}.{kind}';(OUT/name).write_bytes(raw);logs[kind]={'file':name,'bytes':len(raw),'sha256':sha(raw)}
    calls.append({'argv':argv,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'logs':logs})
    (OUT/'CALLS.json').write_text(json.dumps(calls,indent=2)+'\n')
    if result.returncode:raise SystemExit(f'Actual scoped check failed: {argv}')
after=audit();assert before==after and script==Path(__file__).read_bytes()
(OUT/'AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
summary={'status':'PASS','source_head':before['head'],'source_tree':before['tree'],'clean_before_after':True,'actual_physical_inputs':before['physical_count'],'actual_pins':len(before['pins']),'actual_provider_payloads':len(before['provider']),'identity_maps_unchanged':True,'wrapper_sha256':sha(script),'calls':calls,'limits':['Four required static targets and eight owned native corruption tests only; full suite and captured execution not run.','Research build qualification stays on separately reviewed C1; this later clean commit preserves identical executable source.']}
(OUT/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
